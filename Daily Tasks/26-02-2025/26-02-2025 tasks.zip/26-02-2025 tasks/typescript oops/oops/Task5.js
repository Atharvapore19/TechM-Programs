var Student = /** @class */ (function () {
    function Student(name, studentClass) {
        this.name = name;
        this.class = studentClass;
    }
    return Student;
}());
// Example usage:
var student1 = new Student("John Doe", "10th Grade");
console.log(student1);
