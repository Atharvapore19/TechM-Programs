var myAddress = {
    street: "123 Main St",
    city: "Anytown",
    state: "CA",
    zipCode: "12345"
};
// Create a variable using the Person type alias
var person = {
    name: "John Doe",
    age: 30,
    address: myAddress
};
console.log(person);
