var Name = "John Doe";
var age = 30;
console.log("Name: ".concat(Name));
console.log("Age: ".concat(age));
