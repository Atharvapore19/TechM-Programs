// Declare variables of different data types
var num = 10;
var str = "Hello, TypeScript!";
var bool = true;
var undef = undefined;
// Perform basic operations
var numSum = num + 5;
var strConcat = str + " How are you?";
var boolToggle = !bool;
var isUndef = undef === undefined;
// Output the results
console.log("Number:", num);
console.log("Number after addition:", numSum);
console.log("String:", str);
console.log("String after concatenation:", strConcat);
console.log("Boolean:", bool);
console.log("Boolean after toggle:", boolToggle);
console.log("Is undefined:", isUndef);
