var inferredTypeVariable = "Hello, TypeScript!";
function displayType(variable) {
    console.log("The type of the variable is: ".concat(typeof variable));
}
displayType(inferredTypeVariable);
