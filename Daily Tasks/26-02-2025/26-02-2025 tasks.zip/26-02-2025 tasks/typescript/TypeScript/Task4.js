var myNumber = 42;
myNumber = "Hello, TypeScript!";
console.log(myNumber);
