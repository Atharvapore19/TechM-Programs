let myNumber: number = 42;
myNumber = "Hello, TypeScript!"; 

console.log(myNumber);