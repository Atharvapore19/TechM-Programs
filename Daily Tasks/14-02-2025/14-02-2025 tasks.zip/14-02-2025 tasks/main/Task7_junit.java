package junittasks;

public class Task7_junit {
	//Write a Java program that uses assertions with custom error messages to provide 
	//meaningful feedback when a test fails.
	public int multiply(int a, int b) {
        return a * b;
    }
}
