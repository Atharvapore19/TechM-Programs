package junittasks;

public class Task4_junit {
	//Write a Java program that implements parameterized test to verify
	//that a method behaves correctly for different input values.
	public int multiply(int a, int b) {
        return a * b;
    }

}
