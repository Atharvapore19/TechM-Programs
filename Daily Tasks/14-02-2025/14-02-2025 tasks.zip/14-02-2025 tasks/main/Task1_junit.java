package junittasks;

public class Task1_junit {
	//Write a Java unit test case to assert that a given method returns the expected value.
	public int sum(int a, int b) {
        return a + b;
    }

}
